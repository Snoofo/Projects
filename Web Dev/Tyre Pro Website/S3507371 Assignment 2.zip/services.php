
<?php include 'top-module.php'; ?>
    <title>Services</title>
<?php include 'middle-module.php'; ?>
    <div class="content">
      <div class="content1">
        <h2>The Services of The Professionals</h2>
        <div>
          <ul class="product">
            <li>
              <a href="servicing.php">
                <img class="image" src="servicing.png" alt="product1">
                <h4>Servicing</h4>
              </a>
            </li>
            <li>
              <a href="wheelalign.php">
                <img class="image" src="wheelalign.png" alt="product2"/>
                <h4>Wheel Alignments</h4>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
<?php include 'bottom-module.php'; ?>
<?php include_once("/home/eh1/e54061/public_html/wp/debug.php"); ?>