    <div class="footer">
      <a href="http://validator.w3.org/check?uri=referer"><img style="border:0;height:31px"
        src="http://www.w3.org/html/logo/downloads/HTML5_Logo_32.png" alt="HTML Validator" /></a> | 
      <a href="http://jigsaw.w3.org/css-validator/check/referer"><img style="border:0; height:31px"
        src="http://jigsaw.w3.org/css-validator/images/vcss-blue" alt="CSS Validator"/></a> | 
      <a href="http://www.youtube.com">My Links</a> | 
      <a href="privacy.php">View Privacy Policy</a> | Copyright &copy; Stefan Mazaleigue
      <script>
        document.write(new Date().getFullYear());
      </script>
    </div>
    </div>
  </body>

</html>