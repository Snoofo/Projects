
<?php include 'top-module.php'; ?>
    <title>Products</title>
<?php include 'middle-module.php'; ?>
    <div class="content">
      <div class="content1">
        <h2>The Tyres from The Professionals</h2>
        <div>
          <ul class="product">
            <li>
              <!-- Image sourced from www.continental.co.uk for educational purposes only -->
              <a href="fullproduct.php?pid=conti">
                <img class="image" src="contityre.png" alt="product1"/>
                <h4>Continental</h4>
              </a>
            </li>
            <li>
              <!-- Image sourced from www.total911.com for educational purposes only -->
              <a href="fullproduct.php?pid=michelin">
                <img class="image" src="michtyre.png" alt="product2"/>
                <h4>Michelin</h4>
              </a>
            </li>
            <li>
            <!-- Image sourced from www.goodgrip.co.uk for educational purposes only -->
              <a href="fullproduct.php?pid=bstone">
                <img class="image" src="bridgestyre.png" alt="product2"/>
                <h4>Bridgestone</h4>
            </li>
          </ul>
        </div>
      </div>
    </div>
<?php include 'bottom-module.php'; ?>
<?php include_once("/home/eh1/e54061/public_html/wp/debug.php"); ?>