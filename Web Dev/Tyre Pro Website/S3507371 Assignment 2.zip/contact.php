
<?php include 'top-module.php'; ?>
    <title>Contact Us</title>
<?php include 'middle-module.php'; ?>
    <div class="content">
      <div class="content1">
        <h2>Contact The Professionals:</h2><br>
        <p><strong>Address:</strong> 47 Whiting Street, Artarmon<br><br>
        <strong>Phone:</strong> 9436-3980<br><br>
        <strong>Email:</strong> service@tyrepro.net.au</p>
      </div>
    </div>
<?php include 'bottom-module.php'; ?>
<?php include_once("/home/eh1/e54061/public_html/wp/debug.php"); ?>