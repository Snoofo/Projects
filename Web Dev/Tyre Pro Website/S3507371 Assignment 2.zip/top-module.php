<?php
  session_start();
  $_SESSION['products']['bstone'] = 239;
  $_SESSION['products']['conti'] = 249;
  $_SESSION['products']['michelin'] = 269;
?>
<!DOCTYPE HTML>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="keywords" content="tyre pro, tyres, artarmon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href='http://fonts.googleapis.com/css?family=Oswald|Raleway' rel='stylesheet' type='text/css'>
    <script src="jscript.js">
    </script>
    